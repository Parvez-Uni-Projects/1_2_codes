
import exceptions.NoInformationFoundException;

public interface Signal {

    public void checkSignal() throws NoInformationFoundException;
}
