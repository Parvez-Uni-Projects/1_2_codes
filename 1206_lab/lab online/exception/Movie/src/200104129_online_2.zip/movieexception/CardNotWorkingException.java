package movieexception;

public class CardNotWorkingException extends RuntimeException{
    

   

    public CardNotWorkingException(String message)
    {
        super(message);
    }
    
}
