package movieexception;

public class NotApplicableForChildrenException extends Exception {

    public NotApplicableForChildrenException (String message)
    {
        super(message);
    }
    


}

