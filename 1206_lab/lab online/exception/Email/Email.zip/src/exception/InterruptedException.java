package exception;

public class InterruptedException extends Exception{

    public InterruptedException(String message)
    {
        super(message);
    }
    
}
