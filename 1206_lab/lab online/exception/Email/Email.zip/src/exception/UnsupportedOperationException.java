package exception;

public class UnsupportedOperationException extends RuntimeException {

    public UnsupportedOperationException(String message)
    {
        super(message);
    }
    
}
