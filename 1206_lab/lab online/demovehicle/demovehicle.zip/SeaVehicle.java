
public interface SeaVehicle extends Vehicle {
   
   public int getDisplacement();
   public void setDisplacement( int displacement);
        
}
