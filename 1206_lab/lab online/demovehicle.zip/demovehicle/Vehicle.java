
public interface Vehicle {
    
    String getName();
    void setName( String name );
    
    int getMaxPassenger();
    void setMaxPassenger( int maxPassanger );
    
    int getMaxSpeed();
    void setMaxSpeed( int maxSpeed);
    
}
