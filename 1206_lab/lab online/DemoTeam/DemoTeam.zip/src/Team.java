public interface Team {

    public String getName();
    public void setName(String name);

    public int getMaxPlayer();
    public void setMaxPlayer(int maxTrophy);

    public int getMaxTrophy();
    public void setMaxTrophy(int maxTrophy);
    
}
