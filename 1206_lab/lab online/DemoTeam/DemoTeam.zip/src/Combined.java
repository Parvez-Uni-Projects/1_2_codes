public abstract class Combined {
    
    public abstract void worldSound();
    public  void type(){
        System.out.println("This is an Combined Vehicle");
    }
    
}
