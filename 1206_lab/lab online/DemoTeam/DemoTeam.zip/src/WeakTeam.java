public interface WeakTeam extends Team {
    public int getReplacementPlayer();
    public void setReplacementPlayer(int replacementPlayer);
    
}
