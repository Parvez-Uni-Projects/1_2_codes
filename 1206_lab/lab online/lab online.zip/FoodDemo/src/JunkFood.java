public interface JunkFood extends Food {

    public String getHealthIssues();
    public void setHealthIssues(String healthIssues);

    
}
