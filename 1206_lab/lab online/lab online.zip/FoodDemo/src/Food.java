public interface Food {

    public String getName();
    public void setName(String name);

    public double getCalories();
    public void setCalories(double calories);

    public double getFat();
    public void setFat(double fat);

    
}
