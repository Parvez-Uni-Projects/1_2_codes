public interface StrongTeam extends Team {

    public int getNumTournaments();
    public void setNumTournaments(int numTournaments);
    
}
