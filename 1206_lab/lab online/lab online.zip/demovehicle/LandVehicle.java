
public interface LandVehicle extends Vehicle{
    
     public int getNumWheels();
     public void setNumWheels( int numWheels);
}
