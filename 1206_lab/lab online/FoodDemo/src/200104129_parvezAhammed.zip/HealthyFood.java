public interface HealthyFood extends Food {

    public String getNutritionValue();
    public void setNutritionValue(String nutritionValue);
    
}
