
import myexceptions.*;
public interface Signal {

    void inspectSignal () throws InvalidInformationException;
    
}
