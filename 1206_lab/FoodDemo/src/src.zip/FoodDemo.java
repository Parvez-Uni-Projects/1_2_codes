public class FoodDemo {
    public static void main(String[] args) throws Exception {

        HealthyFood milk = new Milk("Is high on calories");
        Milk milk2 = new Milk("Milk",60,10);

        System.out.println("Food is "+milk.getName());

        
        
        

    }
}