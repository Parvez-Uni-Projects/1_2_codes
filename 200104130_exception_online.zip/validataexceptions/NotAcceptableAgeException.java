package validationexceptions;


public class NotAcceptableAgeException extends RuntimeException{

    public NotAcceptableAgeException(String message) {
        super(message);
    }
    
    
     
}