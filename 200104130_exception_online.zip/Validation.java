package validationexceptions;


public interface Validation {
    
    public void validateEmail(String email);
    public void validateAge (int age);
    
}